#!/bin/sh
 
. ./env.sh
JAVA_OPTS=" -Djboss.server.config.user.dir=//configuration"
$ JBOSS_HOME/bin/add-user.sh 
