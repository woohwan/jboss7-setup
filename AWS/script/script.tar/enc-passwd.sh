#!/bin/sh
 
. ./env.sh
 
export CLASSPATH=$JBOSS_HOME/modules/org/picketbox/main/picketbox-4.0.14.Final-redhat-2.jar:$JBOSS_HOME/modules/org/jboss/logging/main/jboss-logging-3.1.2.GA-redhat-1.jar:$CLASSPATH
 
echo "password:$1"
 
java org.picketbox.datasource.security.SecureIdentityLoginModule $1

