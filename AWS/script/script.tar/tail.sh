#!/bin/sh
 
. ./env.sh
 
tail -f $LOG_HOME/server.log
