#!/bin/sh
 
DATE=`date +%Y%m%d%H%M%S`
 
source ./env.sh

 
PID=`ps -ef | grep java | grep "=$SERVER_NAME" | awk '{print $2}'`
 
echo $PID
 
if [ -n "$PID" ]
then
     echo "JBoss SERVER - $SERVER_NAME is already RUNNING..."
     exit;
fi
 
UNAME=`id -u -n`
 
if [ $UNAME != "$JBOSS_USER" ]
then
     echo "Use $JBOSS_USER account to start JBoss SERVER -$SERVER_NAME..."
     exit;
fi
 
echo $JAVA_OPTS

# nohup log 이동 관련 제거, nohup log 파일명에 생성일 추가
nohup $JBOSS_HOME/bin/standalone.sh -DSERVER=$SERVER_NAME -P=$DOMAIN_BASE/$SERVER_NAME/bin/env.properties -c $CONFIG_FILE 2>&1 >> $LOG_HOME/nohup/$SERVER_NAME-$DATE.out &
 
 
if [ "$1" = "notail" ]
then
     echo "Starting... $SERVER_NAME"
     exit;
fi
 
#tail -f $LOG_HOME/server.log    # tail을 nohup 로그에서 server.log로 변경
#tail -f $SERVER_NAME.out
tail -f $LOG_HOME/nohup/$SERVER_NAME-$DATE.out
