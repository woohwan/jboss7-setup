#!/bin/sh
 
DATE=`date +%Y%m%d%H%M%S`
 
##### JBoss Directory Setup #####
export JBOSS_HOME=/JBOSS/jboss-eap-7.4        # 설치된 JBOSS EAP 버전에 맞는 디렉터리 설정
export JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk        # 사용하는 JDK 버전에 맞게 설정
export DOMAIN_BASE=/JBOSS/domains                # 도메인 베이스 디렉터리 설정
export SERVER_NAME="node1"                            # 생성한 노드명 설정
export HOST_NAME=`hostname`                            # 호스트네임을 서버에 정의된 HOSTNAME으로 자동인식 처리
 
##### Configuration File #####
export CONFIG_FILE=standalone-ha.xml                # 환경 설정 파일 등록
export PORT_OFFSET=0                                # 포트 OFFSET 값 등록
export JBOSS_USER=jboss                                # jboss 유저 등록
 
##### Bind Address #####
export BIND_ADDR=`hostname -i`                        # 시스템에 설정된 etho0의 네트워크 IP 값을 자동으로 인식
export MGMT_ADDR=$BIND_ADDR                            # 관리 주소 등록
export CONTROLLER_IP=$MGMT_ADDR                        # 관리자 IP 등록
# export CONTROLLER_IP=127.0.0.1
let CONTROLLER_PORT=9990+$PORT_OFFSET                # 관리자 포트 값 연산
export CONTROLLER_PORT                                # 관리자 포트 등록
export LAUNCH_JBOSS_IN_BACKGROUND=true
 
# Multicast IP for stndalone-ha.xml #####
##### MIP, change Please #####
#export MULTICAST_ADDR=230.20.16.1                    # 멀티 캐스트 ip 설정(같은 클러스터간 동일값)
#export JMS_MULTICAST_ADDR=231.20.16.1                # JMS 멀티 캐스트 IP 설정(같은 클러스터간 동일값)
#export MODCLUSTER_MULTICAST_ADDR=224.20.16.100
 
#export JAVA_OPTS="$JAVA_OPTS -Djboss.default.multicast.address=$MULTICAST_ADDR"
#export JAVA_OPTS="$JAVA_OPTS -Djboss.messaging.group.address=$JMS_MULTICAST_ADDR"
#export JAVA_OPTS="$JAVA_OPTS -Djboss.modcluster.multicast.address=$MODCLUSTER_MULTICAST_ADDR"
 
# LOG 디렉터리 위치 설정
export LOG_HOME=/JBOSS/LOG/$SERVER_NAME
#export LOG_HOME=$DOMAIN_BASE/$SERVER_NAME/log
 
# Jboss System module and User module directory #####
export JBOSS_MODULEPATH=$JBOSS_HOME/modules
 
# JVM Options : Server
export JAVA_OPTS="-server $JAVA_OPTS"
 
# JVM Options : Memory
export JAVA_OPTS="$JAVA_OPTS -Xms512m -Xmx512m -XX:MaxMetaspaceSize=128m"
 
export JAVA_OPTS="$JAVA_OPTS -XX:+PrintGCTimeStamps"
export JAVA_OPTS="$JAVA_OPTS -XX:+PrintGCDetails"
export JAVA_OPTS="$JAVA_OPTS -Xloggc:$LOG_HOME/gclog/gc_$DATE.log"
export JAVA_OPTS="$JAVA_OPTS -XX:+UseParallelGC"
#export JAVA_OPTS="$JAVA_OPTS -XX:+UseConcMaskSweepGC"
export JAVA_OPTS="$JAVA_OPTS -XX:+ExplicitGCInvokesConcurrent"
export JAVA_OPTS="$JAVA_OPTS -XX:+HeapDumpOnOutOfMemoryError"                            # OOME 발생 시 힘덤프 자동 생성
export JAVA_OPTS="$JAVA_OPTS -XX:HeapDumpPath=$LOG_HOME/gclog/java_pid_$DATE.hprof"        # 힙덤프 파일명에 생성일 추가
 
# Linux Large Page Setting
# export JAVA_OPTS="$JAVA_OPTS -XX:+UseLargePages"
 
export JAVA_OPTS="$JAVA_OPTS -verbose:gc"
export JAVA_OPTS="$JAVA_OPTS -Djava.net.preferIPv4Stack=true"
export JAVA_OPTS="$JAVA_OPTS -Dorg.jboss.resolver.warning=true"
export JAVA_OPTS="$JAVA_OPTS -Dsun.rmi.dgc.client.gcInterval=3600000"
export JAVA_OPTS="$JAVA_OPTS -Dsun.rmi.dgc.server.gcInterval=3600000"
export JAVA_OPTS="$JAVA_OPTS -Djboss.modules.system.pkgs=org.jboss.byteman"
export JAVA_OPTS="$JAVA_OPTS -Djava.awt.headless=true"
 
export JAVA_OPTS="$JAVA_OPTS -Djboss.server.base.dir=$DOMAIN_BASE/$SERVER_NAME"
export JAVA_OPTS="$JAVA_OPTS -Djboss.socket.binding.port-offset=$PORT_OFFSET"
export JAVA_OPTS="$JAVA_OPTS -Djboss.node.name=${SERVER_NAME}"
export JAVA_OPTS="$JAVA_OPTS -Djboss.bind.address.management=$MGMT_ADDR"
export JAVA_OPTS="$JAVA_OPTS -Djboss.bind.address=$BIND_ADDR"
export JAVA_OPTS="$JAVA_OPTS -Dserver.mode=local"
 
# Use log4j in application
export JAVA_OPTS="$JAVA_OPTS -Dorg.jboss.as.logging.per-deployment=false"
export JAVA_OPTS="$JAVA_OPTS -Djboss.server.log.dir=$LOG_HOME"
 
echo "================================================="
echo "JBOSS_HOME=$JBOSS_HOME"
echo "DOMAIN_BASE=$DOMAIN_BASE"
echo "SERVER_NAME=$SERVER_NAME"
echo "CONFIG_FILE=$CONFIG_FILE"
echo "BIND_ADDR=$BIND_ADDR"
echo "PORT_OFFSET=$PORT_OFFSET"
echo "CONTROLLER=$CONTROLLER_IP:$CONTROLLER_PORT"
echo "jboss.node.name=${SERVER_NAME}"
echo "================================================="
 
#SCOUTER_OPT="-javaagent:/CLOUD/scouter/agent.java_6_7/scouter.agent.jar -Dscouter.config=/CLOUD/scouter/agent.java_6_7/conf/node01.conf"
#export JAVA_OPTS="$JAVA_OPTS$SCOUTER_OPT"
#export JAVA_OPTS="$JAVA_OPTS -Djboss.modules.system.pkgs=org.jboss.byteman,scouter"
